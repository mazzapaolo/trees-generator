#include "scene.h"

#include "ext/yocto_math.h"
#include "ext/yocto_utils.h"

// converte un mesh in vertici sono condivis
// per ogni faccia, aggiunge i rispettivi vertici a mesh e aggiusta
// gli indici di faccia
// alla fine, fa l'update delle normali
// modifica la shape passata e ne ritorna il puntatore
shape* facet_normals(shape* shp) {
    std::vector<vec3f> f_pos, f_norm;
    std::vector<vec3i> f_trian;
    auto i = 0;
    for(auto f : shp->triangles) {
        auto t = triangle_normal(shp->pos[f.x],shp->pos[f.y],shp->pos[f.z]);
        f_pos.push_back(shp->pos[f.x]);
        f_norm.push_back(t);
        f_pos.push_back(shp->pos[f.y]);
        f_norm.push_back(t);
        f_pos.push_back(shp->pos[f.z]);
        f_norm.push_back(t);
        f_trian.push_back(vec3i{i,i+1,i+2});
        i += 3;
    }
    shp->pos.swap(f_pos);
    shp->norm.swap(f_norm);
    shp->triangles.swap(f_trian);
    return shp;
}

// spota ogni vertice i lungo la normale per una quantità dist_txt[i] * scale
// modifica la shape passata e ne ritorna il puntatore
shape* displace(shape* shp, texture* disp_txt, float scale) {
    for (auto i = 0; i < shp->pos.size(); i++) {
        auto x = int(shp->texcoord[i].x*(disp_txt->ldr.width));
        auto y = int(shp->texcoord[i].y*(disp_txt->ldr.height));
        auto pos = y*disp_txt->ldr.width+x;

        if (pos >= disp_txt->ldr.pixels.size()) pos = pos-disp_txt->ldr.width-1;
        auto pixel = disp_txt->ldr.pixels[pos];
        auto t = vec3f{pixel.x/255.0f, pixel.y/255.0f, pixel.z/255.0f};
        shp->pos[i] = shp->pos[i] + t*scale*shp->norm[i];
    }
    compute_smooth_normals(shp);
    return shp;
}

// implementa catmull-clark sudision eseguiendo la suddivisione level volte
// il primo step della suddivisione, che introduce i nuovi vertici e faccie,
// e' implementato con tesselate()
// modifica la shape passata e ne ritorna il puntatore
shape* catmull_clark(shape* shp, int level) {
    for (auto i=0; i<level; i++) {
        tesselate(shp);
        auto avg_v = std::vector<vec3f>(shp->pos.size(), vec3f{0.0,0.0,0.0});
        auto avg_n = std::vector<float>(shp->pos.size(), 0.0f);
        for (auto t : shp->quads) {
            auto c = (shp->pos[t.x] + shp->pos[t.y] + shp->pos[t.z] + shp->pos[t.w])/4.0f;
            avg_v[t.x] += c, avg_v[t.y] += c, avg_v[t.z] += c, avg_v[t.w] += c;
            avg_n[t.x]++, avg_n[t.y]++, avg_n[t.z]++, avg_n[t.w]++;
        }
        for (auto j=0; j<avg_n.size(); j++) avg_v[j] = avg_v[j]/avg_n[j];
        for (auto k=0; k<shp->pos.size(); k++) shp->pos[k] = shp->pos[k] +(avg_v[k]-shp->pos[k])*(4.0f/avg_n[k]);
    }
    compute_smooth_normals(shp);
    return shp;
}

// crea una quadrato nel piano (x,y) con dimensione [-r,r]x[-r,r]
// il piano ha usteps+1 in x and vsteps+1 in y
// le texture coordinates sono sono in [0,1]x[0,1]
// quindi ogni vertice ha pos=[-u*2+1,-v*2+1,1], norm=[0,0,1], texcooerd=[u,v]
// name e' l'identificativo
// il mesh è fatto di quads con griglia definita da usteps x vsteps
// ogni quad e' definito come [i,j], [i+1,j], [i+1,j+1], [i,j+1]
shape* make_quad(const std::string& name, int usteps, int vsteps, float r) {
    auto* shp = new shape;
    shp->name = name;
    for(auto m = 0; m < vsteps; m++) {
        for (auto n = 0; n < usteps; n++) {
            int i = (usteps+1)*m + n;
            int j = i+usteps+1;
            shp->quads.push_back(vec4i{i,i+1,j+1, j});
        }
    }
    for (auto i = 0; i <= vsteps; i++) {
        for (auto j = 0; j <= usteps; j++) {
            auto u = j/float(usteps);
            auto v = i/float(vsteps);
            shp->pos.push_back(vec3f{u*2-1, v*2-1, 0.0});
            shp->norm.push_back(vec3f{0,0,1});
            shp->texcoord.push_back(vec2f{u,v});
        }
    }
    return shp;
}

// crea una sphera di raggio r in coordinate spheriche con (2 pi u, pi v)
// vedi al descrizione di make_quad()
// name e' l'identificativo
shape* make_sphere(const std::string& name, int usteps, int vsteps, float r) {
    auto* shp = make_quad(name, usteps, vsteps, r);
    shp->pos.clear();
    shp->norm.clear();
    for (auto uv : shp->texcoord) {
        auto uu = float(2*M_PI*uv.x);
        auto vv = float(M_PI*(1-uv.y));
        shp->pos.push_back(vec3f{r*sin(vv)*cos(uu), r*sin(vv)*sin(uu), r*cos(vv)});
    }
    compute_smooth_normals(shp);
    return shp;
}

// crea una geosfera ottenuta tessellando la shape originale con tesselate()
// level volte e poi spontando i vertici risultanti sulla sphere di raggio r
// (i vertici sulla sphera unitaria sono normalize(p))
// name e' l'identificativo
shape* make_geosphere(const std::string& name, int level, float r) {
    const float X = 0.525731112119133606f;
    const float Z = 0.850650808352039932f;
    auto pos = std::vector<vec3f>{{-X, 0.0, Z}, {X, 0.0, Z}, {-X, 0.0, -Z},
        {X, 0.0, -Z}, {0.0, Z, X}, {0.0, Z, -X}, {0.0, -Z, X}, {0.0, -Z, -X},
        {Z, X, 0.0}, {-Z, X, 0.0}, {Z, -X, 0.0}, {-Z, -X, 0.0}};
    auto triangles = std::vector<vec3i>{{0, 1, 4}, {0, 4, 9}, {9, 4, 5},
        {4, 8, 5}, {4, 1, 8}, {8, 1, 10}, {8, 10, 3}, {5, 8, 3}, {5, 3, 2},
        {2, 3, 7}, {7, 3, 10}, {7, 10, 6}, {7, 6, 11}, {11, 6, 0}, {0, 6, 1},
        {6, 10, 1}, {9, 11, 0}, {9, 2, 11}, {9, 5, 2}, {7, 11, 2}};

    auto* shp = new shape;
    shp->name = name;
    for (auto p : pos) { shp->pos.push_back(normalize(p)); }
    shp->norm = shp->pos;
    shp->triangles = triangles;
    for(auto i=0; i<level; i++) tesselate(shp);
    for(auto i=0; i<shp->pos.size(); i++) shp->pos[i] = shp->norm[i]*r;
    return shp;
}

// aggiunge un'instanza alla scena, assicurando che gli oggetti puntati
// dall'instanza (shp, mat, mat->kd_txt) sono anch'essi stati aggiunti alla
// scene almeno una e una sola volta
void add_instance(scene* scn, const std::string& name, const frame3f& f,
    shape* shp, material* mat) {
    if (!shp || !mat) return;

    auto* ist = new instance;
    ist->shp = shp;
    ist->mat = mat;
    ist->frame = f;
    ist->name = name;
    scn->instances.push_back(ist);
    if (std::find(scn->shapes.begin(), scn->shapes.end(), shp) == scn->shapes.end()) scn->shapes.push_back(shp);
    if (std::find(scn->textures.begin(), scn->textures.end(), mat->kd_txt) == scn->textures.end()) scn->textures.push_back(mat->kd_txt);
    if (std::find(scn->materials.begin(), scn->materials.end(), mat) == scn->materials.end()) scn->materials.push_back(mat);
}

// crea an material con i parametrii specifici - name e' l'identificativo
material* make_material(const std::string& name, const vec3f& kd,
    const std::string& kd_txt, const vec3f& ks = {0.04f, 0.04f, 0.04f},
    float rs = 0.01f) {
    auto* mt = new material;
    mt->name = name;
    mt->kd = kd;
    mt->ks = ks;
    mt->rs = rs;
    mt->kd_txt =  new texture;
    mt->kd_txt->filename = kd_txt;
    return mt;
}

// aggiunge num sphere di raggio r in un cerchio di raggio R oreintato come
// specificato da f
void add_sphere_instances(
    scene* scn, const frame3f& f, float R, float r, int num, material* mat) {
    std::string name = "sphere";
    auto* shp = make_sphere(name, 32, 16, r);
    for (auto i=0; i<num; i++) {
        auto theta = (2*M_PI*i)/float(num);
        auto u = (float) cos(theta)*R;
        auto v = (float) sin(theta)*R;
        auto f1 = make_frame3_fromz({u,v+1.25f,0} , {0,0,1});
        f1 = frame3f{f1.z,f1.y, -f1.x,  f1.o};
        add_instance(scn, name+std::to_string(i), f1, shp, mat);
    }
}

scene* init_scene() {
    auto scn = new scene();
    // add floor
    auto mat = new material{"floor"};
    mat->kd = {0.2f, 0.2f, 0.2f};
    mat->kd_txt = new texture{"grid.png"};
    scn->textures.push_back(mat->kd_txt);
    scn->materials.push_back(mat);
    auto shp = new shape{"floor"};
    shp->pos = {{-20, 0, -20}, {20, 0, -20}, {20, 0, 20}, {-20, 0, 20}};
    shp->norm = {{0, 1, 0}, {0, 1, 0}, {0, 1, 0}, {0, 1, 0}};
    shp->texcoord = {{-10, -10}, {10, -10}, {10, 10}, {-10, 10}};
    shp->triangles = {{0, 1, 2}, {0, 2, 3}};
    scn->shapes.push_back(shp);
    scn->instances.push_back(new instance{"floor", identity_frame3f, mat, shp});
    // add light
    auto lshp = new shape{"light"};
    lshp->pos = {{1.4f, 8, 6}, {-1.4f, 8, 6}};
    lshp->points = {0, 1};
    scn->shapes.push_back(lshp);
    auto lmat = new material{"light"};
    lmat->ke = {100, 100, 100};
    scn->materials.push_back(lmat);
    scn->instances.push_back(
        new instance{"light", identity_frame3f, lmat, lshp});
    // add camera
    auto cam = new camera{"cam"};
    cam->frame = lookat_frame3f({0, 4, 10}, {0, 1, 0}, {0, 1, 0});
    cam->fovy = 15 * pif / 180.f;
    cam->aspect = 16.0f / 9.0f;
    cam->aperture = 0;
    cam->focus = length(vec3f{0, 4, 10} - vec3f{0, 1, 0});
    scn->cameras.push_back(cam);
    return scn;
}

int main(int argc, char** argv) {
    // command line parsing
    auto parser =
        yu::cmdline::make_parser(argc, argv, "model", "creates simple scenes");
    auto sceneout = yu::cmdline::parse_opts(
        parser, "--output", "-o", "output scene", "out.obj");
    auto type = yu::cmdline::parse_args(
        parser, "type", "type fo scene to create", "empty", true);
    yu::cmdline::check_parser(parser);

    printf("creating scene %s\n", type.c_str());

    // create scene
    auto scn = init_scene();
    if (type == "empty") {
    } else if (type == "simple") {
        add_instance(scn, "quad", make_frame3_fromz({-1.25f, 1, 0}, {0, 0, 1}),
            make_quad("quad", 16, 16, 1),
            make_material("quad", {1, 1, 1}, "colored.png"));
        add_instance(scn, "sphere", make_frame3_fromz({1.25f, 1, 0}, {0, 0, 1}),
            make_sphere("sphere", 32, 16, 1),
            make_material("sphere", {1, 1, 1}, "colored.png"));
    } else if (type == "instances") {
        add_sphere_instances(scn,
            frame3f{{1, 0, 0}, {0, 1, 0}, {0, 0, 1}, {0, 1.25f, 0}}, 1, 0.1, 16,
            make_material("obj", {1, 1, 1}, "colored.png"));
    } else if (type == "displace") {
        add_instance(scn, "quad1", make_frame3_fromz({-1.25f, 1, 0}, {0, 0, 1}),
            displace(make_quad("quad1", 64, 64, 1), make_grid_texture(256, 256),
                0.5),
            make_material("quad1", {1, 1, 1}, "colored.png"));
        add_instance(scn, "quad2", make_frame3_fromz({1.25f, 1, 0}, {0, 0, 1}),
            displace(make_quad("quad2", 64, 64, 1),
                make_bumpdimple_texture(256, 256), 0.5),
            make_material("quad2", {1, 1, 1}, "colored.png"));
    } else if (type == "normals") {
        add_instance(scn, "smnooth",
            make_frame3_fromz({-1.25f, 1, 0}, {0, 0, 1}),
            make_geosphere("smnooth", 2, 1),
            make_material("smnooth", {0.5f, 0.2f, 0.2f}, ""));
        add_instance(scn, "faceted",
            make_frame3_fromz({1.25f, 1, 0}, {0, 0, 1}),
            facet_normals(make_geosphere("faceted", 2, 1)),
            make_material("faceted", {0.2f, 0.5f, 0.2f}, ""));
    } else if (type == "subdiv") {
        add_instance(scn, "cube",
            make_frame3_fromzx({-1.25f, 1, 0}, {0, 0, 1}, {1, 0, 0}),
            catmull_clark(make_cube("cube"), 4),
            make_material("cube", {0.5f, 0.2f, 0.2f}, ""));
        add_instance(scn, "monkey",
            make_frame3_fromzx({1.25f, 1, 0}, {0, 0, 1}, {1, 0, 0}),
            catmull_clark(make_monkey("monkey"), 2),
            make_material("monkey", {0.2f, 0.5f, 0.2f}, ""));
    } else {
        throw std::runtime_error("bad scene type");
    }

    // save
    printf("saving scene %s\n", sceneout.c_str());
    save_scene(sceneout, scn);
    delete scn;
    return 0;
}
