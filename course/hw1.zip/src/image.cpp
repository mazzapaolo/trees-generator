//
// LICENSE:
//
// Copyright (c) 2016 -- 2017 Fabio Pellacini
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
//

#include "image.h"

// needed for image loading
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

// needed for image writing
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb_image_write.h"

image4f load_image4f(const std::string& filename) {
    // YOUR CODE GOES HERE -----------------------------------
    auto w = 0, h = 0, n = 0;
    auto *data = stbi_loadf(filename.c_str(), &w, &h, &n, 4);
    image4f hdr(w, h);
    auto i = 0;
    for (auto j = 0; j < w*h; j++) {
        hdr.at(j%w, j/w) = {data[i],data[i+1],data[i+2],data[i+3]};
        i += 4;
    }
    stbi_image_free(data);
    return hdr;
}

image4b load_image4b(const std::string& filename) {
    // YOUR CODE GOES HERE -----------------------------------
    auto w = 0, h = 0, n = 0;
    auto *data = stbi_load(filename.c_str(), &w, &h, &n, 4);
    image4b ldr(w, h);
    auto i = 0;
    for (auto j = 0; j < w*h; j++) {
        ldr.at(j%w, j/w) = {data[i],data[i+1],data[i+2],data[i+3]};
        i += 4;
    }
    stbi_image_free(data);
    return ldr;
}

void save_image(const std::string& filename, const image4f& img) {
    // YOUR CODE GOES HERE -----------------------------------
    stbi_write_hdr(filename.c_str(), img.width, img.height, 4, &img.pixels[0].x);
}

void save_image(const std::string& filename, const image4b& img) {
    // YOUR CODE GOES HERE -----------------------------------
    stbi_write_png(filename.c_str(), img.width, img.height, 4, &img.pixels[0], 0);
}

image4b tonemap(
    const image4f& hdr, float exposure, bool use_filmic, bool no_srgb) {
    // YOUR CODE GOES HERE -----------------------------------
    auto x = 0, y = 0;
    auto r = 0.0, g = 0.0, b = 0.0;
    image4b ldr(hdr.width, hdr.height);

    for (auto i = 0; i < hdr.width*hdr.height; i++) {
        x = i%ldr.width, y = i/ldr.width;

        r = pow(2, exposure)*hdr.at(x, y).x;
        g = pow(2, exposure)*hdr.at(x, y).y;
        b = pow(2, exposure)*hdr.at(x, y).z;

        if (use_filmic) {
            r = (r*(2.51*r+0.03))/(r*(2.43*r+0.59)+0.14);
            g = (g*(2.51*g+0.03))/(g*(2.43*g+0.59)+0.14);
            b = (b*(2.51*b+0.03))/(b*(2.43*b+0.59)+0.14);
        }

        if (!no_srgb) {
            r = pow(r, 1/2.2);
            g = pow(g, 1/2.2);
            b = pow(b, 1/2.2);
        }

        if (r>=1) r=1;
        if (g>=1) g=1;
        if (b>=1) b=1;

        ldr.at(x, y).x = (unsigned char) int(r*255);
        ldr.at(x, y).y = (unsigned char) int(g*255);
        ldr.at(x, y).z = (unsigned char) int(b*255);
        ldr.at(x, y).w = (unsigned char) int(hdr.at(x, y).w*255);
    }

    return ldr;
}

image4b compose(
    const std::vector<image4b>& imgs, bool premultiplied, bool no_srgb) {
    // YOUR CODE GOES HERE -----------------------------------
    auto x = 0, y = 0, i = 0;
    auto n = 0.0f;
    auto gamma = no_srgb ? 1.0f : 2.2f;
    auto alphaA = 0.0f, alphaB = 0.0f;

    image4b ldr(imgs[0].width, imgs[0].height);
    std::vector<float> data(unsigned(imgs[0].width*imgs[0].height*4), 0.0);

    for (auto img : imgs) {
        i = 0;
        for (auto pixel : img.pixels) {
            n = pixel.w/255.0f;
            alphaA = premultiplied ? 1 : n;
            alphaB = premultiplied ? 1 : data[i+3];

            data[i] = alphaA*pow((pixel.x/255.0f), gamma) + (1-n)*alphaB*data[i];
            data[i+1] = alphaA*pow((pixel.y/255.0f), gamma) + (1-n)*alphaB*data[i+1];
            data[i+2] = alphaA*pow((pixel.z/255.0f), gamma) + (1-n)*alphaB*data[i+2];
            data[i+3] = n + (1-n)*data[i+3];
            i += 4;
        }
    }

    i = 0;
    for (auto j = 0; j < ldr.width*ldr.height; j++) {
        x = j%ldr.width, y = j/ldr.width;
        ldr.at(x, y).x = (unsigned char) int(pow(data[i], 1/gamma)*255);
        ldr.at(x, y).y = (unsigned char) int(pow(data[i+1], 1/gamma)*255);
        ldr.at(x, y).z = (unsigned char) int(pow(data[i+2], 1/gamma)*255);
        ldr.at(x, y).w = (unsigned char) int(data[i+3]*255);
        i +=4;
    }

    return ldr;
}
