#include "scene.h"

#include <thread>
#include "ext/yocto_utils.h"

ray3f eval_camera(const camera* cam, const vec2f& uv) {
    // IL TUO CODICE VA QUI
    auto h = 2.0f*tan(cam->fovy/2.0f);
    auto w = h * cam->aspect;
    auto q = cam->frame.o + cam->frame.x*(uv.x-0.5f)*w + cam->frame.y*(1-uv.y -0.5f)*h - cam->frame.z;
    return ray3f{cam->frame.o, normalize(q-cam->frame.o)};
}

vec3f lookup_texture(const texture* txt, int i, int j, bool srgb) {
    // IL TUO CODICE VA QUI
    auto esp = srgb ? 2.2f : 1.0f;
    return {pow(float(txt->ldr.at(i,j).x)/255.0f, esp),
            pow(float(txt->ldr.at(i,j).y)/255.0f, esp),
            pow(float(txt->ldr.at(i,j).z)/255.0f, esp)};
}

vec3f eval_texture(const texture* txt, const vec2f& texcoord, bool srgb) {
    // IL TUO CODICE VA QUI
    auto s = fmod(texcoord.x, 1.0f) * txt->ldr.width, t = fmod(texcoord.y, 1.0f) * txt->ldr.height;
    auto i = int(floor(s)), j = int(floor(t));
    auto i1 = int(fmod(i+1.0f, txt->ldr.width)), j1 = int(fmod(j+1.0f, txt->ldr.height));
    auto wi = s-i, wj = t-j;

    return lookup_texture(txt, i, j, srgb)*(1.0f-wi)*(1.0f-wj)
         + lookup_texture(txt, i, j1, srgb)*(1.0f-wi)*wj
         + lookup_texture(txt, i1, j, srgb)*wi*(1.0f-wj)
         + lookup_texture(txt, i1, j1, srgb)*wi*wj;
}

vec4f shade(const scene* scn, const std::vector<instance*>& lights,
    const vec3f& amb, const ray3f& ray) {
    if (!intersect_any(scn, ray)) return {0,0,0,0};
    auto isec = intersect_first(scn, ray);
    auto n = transform_direction(isec.ist->frame, eval_norm(isec.ist->shp, isec.ei, isec.ew));
    auto p = transform_point(isec.ist->frame, eval_pos(isec.ist->shp, isec.ei, isec.ew));
    auto v = normalize(ray.o -p);

    auto c = vec3f{0,0,0};
    auto kd = vec3f{0,0,0};

    if (isec.ist->mat->kd_txt != nullptr) kd += eval_texture(isec.ist->mat->kd_txt,
                                                             eval_texcoord(isec.ist->shp, isec.ei, isec.ew), true)*isec.ist->mat->kd;
    else kd = isec.ist->mat->kd;

    for (auto light : lights) {
        if (light->mat->ke.x != 0 || light->mat->ke.y != 0 || light->mat->ke.z != 0) {
            auto pos = transform_point(light->frame ,light->shp->pos.front());
            auto l = normalize(pos - p);
            l = transform_direction(isec.ist->frame, l);
            auto r = length(pos - p);
            auto sr = ray3f{p,l,0.01f,r-0.01f};
            if (intersect_any(scn, sr)) continue;
            auto h = normalize(l+v);
            auto ns = (isec.ist->mat->rs) ? 2.0f / pow(isec.ist->mat->rs, 4.0f) - 2.0f : 1e6f;

            if (!isec.ist->shp->lines.empty()) {
                auto t = line_tangent(isec.ist->shp->pos[isec.ist->shp->lines[isec.ei].x],
                                      isec.ist->shp->pos[isec.ist->shp->lines[isec.ei].y]);
                c += kd*light->mat->ke/(r*r) * sqrt(1.0f-dot(t,l))
                   + isec.ist->mat->ks * light->mat->ke/(r*r) * pow(sqrt(1.0f-dot(t,h)), ns);
            } else {
                c += kd*light->mat->ke/(r*r) * max(0.0f, dot(n,l))
                   + isec.ist->mat->ks * light->mat->ke/(r*r) * pow(max(0.0f, dot(n,h)), ns);
            }
        }
    }

    if (isec.ist->mat->kd_txt != nullptr) c += kd*amb;
    else c += isec.ist->mat->kd*amb;

    if (isec.ist->mat->kr.x != 0 && isec.ist->mat->kr.y != 0 && isec.ist->mat->kr.y != 0) {
        auto ray2 = ray3f{p, n*2.0f*dot(n, v)-v, ray.tmin, ray.tmax};
        auto ref = shade(scn, scn->instances, amb, ray2);
        c += isec.ist->mat->kr * vec3f{ref.x, ref.y, ref.z};
    }
    return vec4f{c.x, c.y, c.z, 1};
}

image4f raytrace(
    const scene* scn, const vec3f& amb, int resolution, int samples) {
    auto cam = scn->cameras.front();
    auto img = image4f((int)std::round(cam->aspect * resolution), resolution);

    for (auto j = 0; j < img.height; j++) {
        for (auto i = 0; i < img.width; i++) {
            for (auto sj = 0; sj < samples; sj++) {
                for (auto si = 0; si < samples; si++) {
                    auto u = (i+(si+0.5f)/samples)/img.width;
                    auto v = (j+(sj+0.5f)/samples-1)/img.height;
                    auto ray = eval_camera(cam, {u, v});
                    img.at(i,j) += shade(scn, scn->instances, amb, ray);
                }
            }
            img.at(i,j) = {img.at(i,j).x/(samples*samples), img.at(i,j).y/(samples*samples), img.at(i,j).z/(samples*samples), 1};
        }
    }
    return img;
}

int main(int argc, char** argv) {
    // command line parsing
    auto parser =
        yu::cmdline::make_parser(argc, argv, "raytrace", "raytrace scene");
    auto resolution = yu::cmdline::parse_opti(
        parser, "--resolution", "-r", "vertical resolution", 720);
    auto samples = yu::cmdline::parse_opti(
        parser, "--samples", "-s", "per-pixel samples", 1);
    auto amb = yu::cmdline::parse_optf(
        parser, "--ambient", "-a", "ambient color", 0.1f);
    auto imageout = yu::cmdline::parse_opts(
        parser, "--output", "-o", "output image", "out.png");
    auto scenein = yu::cmdline::parse_args(
        parser, "scenein", "input scene", "scene.obj", true);
    yu::cmdline::check_parser(parser);

    // load scene
    printf("loading scene %s\n", scenein.c_str());
    auto scn = load_scene(scenein);

    // create bvh
    printf("creating bvh\n");
    build_bvh(scn, false);

    // raytrace
    printf("tracing scene\n");
    auto hdr = raytrace(scn, vec3f{amb, amb, amb}, resolution, samples);

    // tonemap and save
    printf("saving image %s\n", imageout.c_str());
    save_hdr_or_ldr(imageout, hdr);
}
